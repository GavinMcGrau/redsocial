import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-usuari',
  templateUrl: './pagina-usuari.component.html',
  styleUrls: ['./pagina-usuari.component.css']
})
export class PaginaUsuariComponent implements OnInit {

  constructor() {
    
   }

  ngOnInit(): void {
  }

}
