export interface Usuario{
    nombre:string,
    apellidos:string,
    edad:number,
    foto:string,
    correo:string,
    descripcion:string,
    contrasenya:string
}